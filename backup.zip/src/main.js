document.getElementsByClassName('sign-in')[0].addEventListener("click", () => {
    window.location = './login'
});
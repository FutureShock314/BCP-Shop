# How to Use

- run `npm install`
- run `npx webpack`
- run `npx serve dist`
- go to the address given
- check the console in inspect to see the output!

May need to be ran in cmd and bash not powershell

- To update the webpage, change `'./dist/index.html'`
- To update the javascript, change `'./src/index.js'`

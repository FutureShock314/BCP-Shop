# How to Use

- run `npm install`
- run `npx webpack`
- run `serve dist`
  - You may need to run `npm install --global serve`
- go to the address given
- check the console in inspect to see the output!

May need to be ran in cmd and bash not powershell

- To update the webpage, change `'./dist/index.html'`
- To update the javascript, change `'./src/index.js'`
